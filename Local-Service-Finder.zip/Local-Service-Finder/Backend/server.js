const path = require("path");
const express = require("express");
const cors = require("cors");
require("dotenv").config();

const db = require("./config/db");

const authRoutes = require("./routes/authRoutes");
const serviceRoutes = require("./routes/serviceRoutes");
const adminRoutes = require("./routes/adminRoutes");
const providerRoutes = require("./routes/providerRoutes");
const requestRoutes = require("./routes/requestRoutes");
const reviewRoutes = require("./routes/reviewRoutes");
const categoryRoutes = require("./routes/categoryRoutes");

const app = express();


// ========================================
// MIDDLEWARE
// ========================================

app.use(cors());



app.use(express.json());

app.use(express.urlencoded({ extended: true }));
app.use(
    "/uploads",
    express.static(path.join(__dirname, "uploads"))
);

// ========================================
// AUTHENTICATION ROUTES
// ========================================

app.use("/api/auth", authRoutes);
app.use("/api/services", serviceRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/provider", providerRoutes);
app.use("/api/requests", requestRoutes);
app.use("/api/reviews", reviewRoutes);
app.use("/api/categories", categoryRoutes);

// ========================================
// HOME / API TEST ROUTE
// ========================================

app.get("/", (req, res) => {

    res.json({
        success: true,
        message: "Local Service Finder API is running"
    });

});


// ========================================
// DATABASE TEST ROUTE
// ========================================

app.get("/api/test-db", (req, res) => {

    const sql = "SELECT * FROM categories";

    db.query(sql, (err, results) => {

        if (err) {

            return res.status(500).json({
                success: false,
                message: "Database query failed",
                error: err.message
            });

        }

        res.json({
            success: true,
            message: "Database working successfully",
            categories: results
        });

    });

});


// ========================================
// 404 ROUTE
// ========================================

app.use((req, res) => {

    res.status(404).json({
        success: false,
        message: "API route not found"
    });

});


// ========================================
// START SERVER
// ========================================

const PORT = 5000;

app.listen(PORT, () => {

    console.log("======================================");
    console.log("🚀 Local Service Finder Backend");
    console.log(`🌐 Server: http://localhost:${PORT}`);
    console.log("======================================");

});