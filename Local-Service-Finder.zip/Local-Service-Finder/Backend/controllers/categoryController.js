const db = require("../config/db");

const getAllCategories = (req, res) => {

    const sql = `
        SELECT
            category_id,
            category_name
        FROM categories
        ORDER BY category_name ASC
    `;

    db.query(sql, (err, results) => {

        if (err) {
            return res.status(500).json({
                success: false,
                message: "Failed to fetch categories",
                error: err.message
            });
        }

        res.json({
            success: true,
            count: results.length,
            categories: results
        });
    });
};

module.exports = {
    getAllCategories
};