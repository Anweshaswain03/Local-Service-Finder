const db = require("../config/db");

// ==========================================
// Create Service Request
// ==========================================
const createRequest = (req, res) => {

    const userId = req.user.userId;

    const {
        service_id,
        message
    } = req.body;

    if (!service_id) {
        return res.status(400).json({
            success: false,
            message: "Service ID is required"
        });
    }

    // Check whether service exists and is available
    const checkServiceSql = `
        SELECT
            service_id,
            provider_id,
            service_name,
            availability,
            status
        FROM services
        WHERE service_id = ?
    `;

    db.query(
        checkServiceSql,
        [service_id],
        (err, results) => {

            if (err) {
                return res.status(500).json({
                    success: false,
                    message: "Database error",
                    error: err.message
                });
            }

            if (results.length === 0) {
                return res.status(404).json({
                    success: false,
                    message: "Service not found"
                });
            }

            const service = results[0];

            // Only approved services can receive requests
            if (service.status !== "approved") {
                return res.status(400).json({
                    success: false,
                    message: "This service is not approved"
                });
            }

            // Service must be available
            if (service.availability !== "available") {
                return res.status(400).json({
                    success: false,
                    message: "This service is currently unavailable"
                });
            }

            // Customer cannot request their own service
            if (service.provider_id === userId) {
                return res.status(400).json({
                    success: false,
                    message: "You cannot request your own service"
                });
            }

            // Check for existing pending request
            const checkRequestSql = `
                SELECT request_id
                FROM service_requests
                WHERE user_id = ?
                AND service_id = ?
                AND request_status = 'pending'
            `;

            db.query(
                checkRequestSql,
                [userId, service_id],
                (err, existingRequests) => {

                    if (err) {
                        return res.status(500).json({
                            success: false,
                            message: "Database error",
                            error: err.message
                        });
                    }

                    if (existingRequests.length > 0) {
                        return res.status(409).json({
                            success: false,
                            message: "You already have a pending request for this service"
                        });
                    }

                    // Create request
                    const insertSql = `
                        INSERT INTO service_requests
                        (
                            user_id,
                            service_id,
                            message
                        )
                        VALUES (?, ?, ?)
                    `;

                    db.query(
                        insertSql,
                        [
                            userId,
                            service_id,
                            message || null
                        ],
                        (err, result) => {

                            if (err) {
                                return res.status(500).json({
                                    success: false,
                                    message: "Failed to create service request",
                                    error: err.message
                                });
                            }

                            res.status(201).json({
                                success: true,
                                message: "Service request sent successfully",
                                request_id: result.insertId
                            });
                        }
                    );
                }
            );
        }
    );
};


// ==========================================
// Get Customer's Own Requests
// ==========================================
const getMyRequests = (req, res) => {

    const userId = req.user.userId;

    const sql = `
        SELECT
            sr.request_id,
            sr.message,
            sr.request_status,
            sr.created_at,

            s.service_id,
            s.service_name,
            s.location,
            s.contact_number,

            u.user_id AS provider_id,
            u.name AS provider_name,
            u.email AS provider_email,
            u.phone AS provider_phone

        FROM service_requests sr

        INNER JOIN services s
            ON sr.service_id = s.service_id

        INNER JOIN users u
            ON s.provider_id = u.user_id

        WHERE sr.user_id = ?

        ORDER BY sr.created_at DESC
    `;

    db.query(
        sql,
        [userId],
        (err, results) => {

            if (err) {
                return res.status(500).json({
                    success: false,
                    message: "Failed to fetch your requests",
                    error: err.message
                });
            }

            res.json({
                success: true,
                count: results.length,
                requests: results
            });
        }
    );
};


// ==========================================
// Cancel Pending Request
// ==========================================
const cancelRequest = (req, res) => {

    const userId = req.user.userId;
    const requestId = req.params.id;

    const sql = `
        DELETE FROM service_requests
        WHERE request_id = ?
        AND user_id = ?
        AND request_status = 'pending'
    `;

    db.query(
        sql,
        [requestId, userId],
        (err, result) => {

            if (err) {
                return res.status(500).json({
                    success: false,
                    message: "Failed to cancel request",
                    error: err.message
                });
            }

            if (result.affectedRows === 0) {
                return res.status(404).json({
                    success: false,
                    message: "Pending request not found"
                });
            }

            res.json({
                success: true,
                message: "Service request cancelled successfully"
            });
        }
    );
};


module.exports = {
    createRequest,
    getMyRequests,
    cancelRequest
};