const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const db = require("../config/db");


// ========================================
// REGISTER USER
// ========================================

const registerUser = async (req, res) => {

    try {

        const {
            name,
            email,
            password,
            phone,
            role
        } = req.body;


        // Check required fields
        if (!name || !email || !password) {

            return res.status(400).json({
                success: false,
                message: "Name, email and password are required"
            });

        }


        // Check if email already exists
        const checkSql = "SELECT * FROM users WHERE email = ?";

        db.query(checkSql, [email], async (err, results) => {

            if (err) {

                return res.status(500).json({
                    success: false,
                    message: "Database error",
                    error: err.message
                });

            }


            if (results.length > 0) {

                return res.status(409).json({
                    success: false,
                    message: "Email already registered"
                });

            }


            // Hash password
            const hashedPassword = await bcrypt.hash(password, 10);


            // Only allow user/provider during registration
            const userRole =
            role === "provider" ? "provider" : "user";

            // Insert user
            const insertSql = `
                INSERT INTO users
                (name, email, password, phone, role)
                VALUES (?, ?, ?, ?, ?)
            `;

            db.query(
                insertSql,
                [
                    name,
                    email,
                    hashedPassword,
                    phone || null,
                    userRole
                ],
                (err, result) => {

                    if (err) {

                        return res.status(500).json({
                            success: false,
                            message: "Registration failed",
                            error: err.message
                        });

                    }


                    res.status(201).json({
                        success: true,
                        message: "Registration successful",
                        userId: result.insertId
                    });

                }
            );

        });

    } catch (error) {

        res.status(500).json({
            success: false,
            message: "Server error",
            error: error.message
        });

    }

};


// ========================================
// LOGIN USER
// ========================================

const loginUser = (req, res) => {

    const {
        email,
        password
    } = req.body;


    if (!email || !password) {

        return res.status(400).json({
            success: false,
            message: "Email and password are required"
        });

    }


    const sql = "SELECT * FROM users WHERE email = ?";

    db.query(sql, [email], async (err, results) => {

        if (err) {

            return res.status(500).json({
                success: false,
                message: "Database error",
                error: err.message
            });

        }


        if (results.length === 0) {

            return res.status(401).json({
                success: false,
                message: "Invalid email or password"
            });

        }


        const user = results[0];


        // Check account status
        if (user.status !== "active") {

            return res.status(403).json({
                success: false,
                message: "Your account is blocked"
            });

        }


        // Compare password
        const passwordMatch =
            await bcrypt.compare(password, user.password);


        if (!passwordMatch) {

            return res.status(401).json({
                success: false,
                message: "Invalid email or password"
            });

        }


        // Create JWT
        const token = jwt.sign(
            {
                userId: user.user_id,
                role: user.role,
                email: user.email
            },
            process.env.JWT_SECRET,
            {
                expiresIn: "1d"
            }
        );


        res.json({
            success: true,
            message: "Login successful",
            token,
            user: {
                userId: user.user_id,
                name: user.name,
                email: user.email,
                phone: user.phone,
                role: user.role
            }
        });

    });

};


module.exports = {
    registerUser,
    loginUser
};