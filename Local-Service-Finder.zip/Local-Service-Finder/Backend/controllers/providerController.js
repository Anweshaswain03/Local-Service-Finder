const db = require("../config/db");

// ==========================================
// Get Provider's Own Services
// ==========================================
const getMyServices = (req, res) => {

    const providerId = req.user.userId;

    const sql = `
        SELECT
            s.service_id,
            s.service_name,
            s.location,
            s.address,
            s.description,
            s.contact_number,
            s.image,
            s.availability,
            s.status,
            s.created_at,
            c.category_name
        FROM services s

        INNER JOIN categories c
            ON s.category_id = c.category_id

        WHERE s.provider_id = ?

        ORDER BY s.created_at DESC
    `;

    db.query(sql, [providerId], (err, results) => {

        if (err) {
            return res.status(500).json({
                success: false,
                message: "Failed to fetch your services",
                error: err.message
            });
        }

        res.json({
            success: true,
            count: results.length,
            services: results
        });
    });
};
// Get Provider Dashboard Statistics
const getProviderStats = (req, res) => {

    const providerId = req.user.userId;

    const serviceStatsSql = `
        SELECT
            COUNT(*) AS total_services,

            SUM(CASE
                WHEN status = 'approved' THEN 1
                ELSE 0
            END) AS approved_services,

            SUM(CASE
                WHEN status = 'pending' THEN 1
                ELSE 0
            END) AS pending_services,

            SUM(CASE
                WHEN status = 'rejected' THEN 1
                ELSE 0
            END) AS rejected_services,

            SUM(CASE
                WHEN availability = 'available' THEN 1
                ELSE 0
            END) AS available_services,

            SUM(CASE
                WHEN availability = 'unavailable' THEN 1
                ELSE 0
            END) AS unavailable_services

        FROM services
        WHERE provider_id = ?
    `;

    const requestStatsSql = `
        SELECT
            COUNT(sr.request_id) AS total_requests,

            SUM(CASE
                WHEN sr.request_status = 'pending' THEN 1
                ELSE 0
            END) AS pending_requests,

            SUM(CASE
                WHEN sr.request_status = 'accepted' THEN 1
                ELSE 0
            END) AS accepted_requests,

            SUM(CASE
                WHEN sr.request_status = 'rejected' THEN 1
                ELSE 0
            END) AS rejected_requests,

            SUM(CASE
                WHEN sr.request_status = 'completed' THEN 1
                ELSE 0
            END) AS completed_requests

        FROM service_requests sr

        INNER JOIN services s
            ON sr.service_id = s.service_id

        WHERE s.provider_id = ?
    `;

    db.query(
        serviceStatsSql,
        [providerId],
        (err, serviceResults) => {

            if (err) {
                return res.status(500).json({
                    success: false,
                    message: "Failed to fetch service statistics",
                    error: err.message
                });
            }

            db.query(
                requestStatsSql,
                [providerId],
                (err, requestResults) => {

                    if (err) {
                        return res.status(500).json({
                            success: false,
                            message: "Failed to fetch request statistics",
                            error: err.message
                        });
                    }

                    const services = serviceResults[0];
                    const requests = requestResults[0];

                    res.json({
                        success: true,

                        statistics: {
                            services: {
                                total: Number(services.total_services),
                                approved: Number(services.approved_services),
                                pending: Number(services.pending_services),
                                rejected: Number(services.rejected_services),
                                available: Number(services.available_services),
                                unavailable: Number(services.unavailable_services)
                            },

                            requests: {
                                total: Number(requests.total_requests),
                                pending: Number(requests.pending_requests),
                                accepted: Number(requests.accepted_requests),
                                rejected: Number(requests.rejected_requests),
                                completed: Number(requests.completed_requests)
                            }
                        }
                    });
                }
            );
        }
    );
};

// ==========================================
// Update Provider's Own Service
// ==========================================
const updateMyService = (req, res) => {

    const providerId = req.user.userId;
    const serviceId = req.params.id;

    const {
        service_name,
        category_id,
        location,
        address,
        description,
        contact_number
    } = req.body;

    if (!service_name || !category_id || !location) {
        return res.status(400).json({
            success: false,
            message: "Service name, category and location are required"
        });
    }

    // If a new image is uploaded, save its path
    const imagePath = req.file
        ? `/uploads/${req.file.filename}`
        : null;

    let sql;
    let values;

    if (req.file) {

        // Update including new image
        sql = `
            UPDATE services
            SET
                service_name = ?,
                category_id = ?,
                location = ?,
                address = ?,
                description = ?,
                contact_number = ?,
                image = ?,
                status = 'pending'
            WHERE service_id = ?
            AND provider_id = ?
        `;

        values = [
            service_name,
            category_id,
            location,
            address || null,
            description || null,
            contact_number || null,
            imagePath,
            serviceId,
            providerId
        ];

    } else {

        // Update without changing existing image
        sql = `
            UPDATE services
            SET
                service_name = ?,
                category_id = ?,
                location = ?,
                address = ?,
                description = ?,
                contact_number = ?,
                status = 'pending'
            WHERE service_id = ?
            AND provider_id = ?
        `;

        values = [
            service_name,
            category_id,
            location,
            address || null,
            description || null,
            contact_number || null,
            serviceId,
            providerId
        ];
    }

    db.query(sql, values, (err, result) => {

        if (err) {
            return res.status(500).json({
                success: false,
                message: "Failed to update service",
                error: err.message
            });
        }

        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: "Service not found or you do not own this service"
            });
        }

        res.json({
            success: true,
            message: req.file
                ? "Service updated with new image and sent for re-approval"
                : "Service updated successfully and sent for re-approval",
            image: imagePath
        });
    });
};

// ==========================================
// Delete Provider's Own Service
// ==========================================
const deleteMyService = (req, res) => {

    const providerId = req.user.userId;
    const serviceId = req.params.id;

    const sql = `
        DELETE FROM services
        WHERE service_id = ?
        AND provider_id = ?
    `;

    db.query(sql, [serviceId, providerId], (err, result) => {

        if (err) {
            return res.status(500).json({
                success: false,
                message: "Failed to delete service",
                error: err.message
            });
        }

        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: "Service not found or you do not own this service"
            });
        }

        res.json({
            success: true,
            message: "Service deleted successfully"
        });
    });
};


// ==========================================
// Change Service Availability
// ==========================================
const updateAvailability = (req, res) => {

    const providerId = req.user.userId;
    const serviceId = req.params.id;

    const { availability } = req.body;

    if (!["available", "unavailable"].includes(availability)) {
        return res.status(400).json({
            success: false,
            message: "Availability must be available or unavailable"
        });
    }

    const sql = `
        UPDATE services
        SET availability = ?
        WHERE service_id = ?
        AND provider_id = ?
    `;

    db.query(
        sql,
        [availability, serviceId, providerId],
        (err, result) => {

            if (err) {
                return res.status(500).json({
                    success: false,
                    message: "Failed to update availability",
                    error: err.message
                });
            }

            if (result.affectedRows === 0) {
                return res.status(404).json({
                    success: false,
                    message: "Service not found or you do not own this service"
                });
            }

            res.json({
                success: true,
                message: "Service availability updated successfully"
            });
        }
    );
};
// ==========================================
// Get Incoming Service Requests
// ==========================================
const getProviderRequests = (req, res) => {

    const providerId = req.user.userId;

    const sql = `
        SELECT
            sr.request_id,
            sr.message,
            sr.request_status,
            sr.created_at,

            s.service_id,
            s.service_name,
            s.location,

            u.user_id AS customer_id,
            u.name AS customer_name,
            u.email AS customer_email,
            u.phone AS customer_phone

        FROM service_requests sr

        INNER JOIN services s
            ON sr.service_id = s.service_id

        INNER JOIN users u
            ON sr.user_id = u.user_id

        WHERE s.provider_id = ?

        ORDER BY sr.created_at DESC
    `;

    db.query(sql, [providerId], (err, results) => {

        if (err) {
            return res.status(500).json({
                success: false,
                message: "Failed to fetch service requests",
                error: err.message
            });
        }

        res.json({
            success: true,
            count: results.length,
            requests: results
        });
    });
};


// ==========================================
// Accept Service Request
// ==========================================
const acceptRequest = (req, res) => {

    const providerId = req.user.userId;
    const requestId = req.params.id;

    const sql = `
        UPDATE service_requests sr

        INNER JOIN services s
            ON sr.service_id = s.service_id

        SET sr.request_status = 'accepted'

        WHERE sr.request_id = ?
        AND s.provider_id = ?
        AND sr.request_status = 'pending'
    `;

    db.query(
        sql,
        [requestId, providerId],
        (err, result) => {

            if (err) {
                return res.status(500).json({
                    success: false,
                    message: "Failed to accept request",
                    error: err.message
                });
            }

            if (result.affectedRows === 0) {
                return res.status(404).json({
                    success: false,
                    message: "Pending request not found or you do not own this service"
                });
            }

            res.json({
                success: true,
                message: "Service request accepted successfully"
            });
        }
    );
};


// ==========================================
// Reject Service Request
// ==========================================
const rejectRequest = (req, res) => {

    const providerId = req.user.userId;
    const requestId = req.params.id;

    const sql = `
        UPDATE service_requests sr

        INNER JOIN services s
            ON sr.service_id = s.service_id

        SET sr.request_status = 'rejected'

        WHERE sr.request_id = ?
        AND s.provider_id = ?
        AND sr.request_status = 'pending'
    `;

    db.query(
        sql,
        [requestId, providerId],
        (err, result) => {

            if (err) {
                return res.status(500).json({
                    success: false,
                    message: "Failed to reject request",
                    error: err.message
                });
            }

            if (result.affectedRows === 0) {
                return res.status(404).json({
                    success: false,
                    message: "Pending request not found or you do not own this service"
                });
            }

            res.json({
                success: true,
                message: "Service request rejected successfully"
            });
        }
    );
};


// ==========================================
// Mark Request as Completed
// ==========================================
const completeRequest = (req, res) => {

    const providerId = req.user.userId;
    const requestId = req.params.id;

    const sql = `
        UPDATE service_requests sr

        INNER JOIN services s
            ON sr.service_id = s.service_id

        SET sr.request_status = 'completed'

        WHERE sr.request_id = ?
        AND s.provider_id = ?
        AND sr.request_status = 'accepted'
    `;

    db.query(
        sql,
        [requestId, providerId],
        (err, result) => {

            if (err) {
                return res.status(500).json({
                    success: false,
                    message: "Failed to complete request",
                    error: err.message
                });
            }

            if (result.affectedRows === 0) {
                return res.status(404).json({
                    success: false,
                    message: "Accepted request not found or you do not own this service"
                });
            }

            res.json({
                success: true,
                message: "Service request marked as completed"
            });
        }
    );
};

module.exports = {
    getMyServices,
    getProviderStats,
    updateMyService,
    deleteMyService,
    updateAvailability,
    getProviderRequests,
    acceptRequest,
    rejectRequest,
    completeRequest
};