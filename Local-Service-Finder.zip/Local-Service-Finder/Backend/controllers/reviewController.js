const db = require("../config/db");

// ==========================================
// Add Review & Rating
// ==========================================
const addReview = (req, res) => {

    const userId = req.user.userId;

    const {
        service_id,
        rating,
        comment
    } = req.body;

    // Validate required fields
    if (!service_id || !rating) {
        return res.status(400).json({
            success: false,
            message: "Service ID and rating are required"
        });
    }

    // Validate rating
    if (rating < 1 || rating > 5) {
        return res.status(400).json({
            success: false,
            message: "Rating must be between 1 and 5"
        });
    }

    // Check whether customer has completed request
    const checkRequestSql = `
        SELECT request_id
        FROM service_requests
        WHERE user_id = ?
        AND service_id = ?
        AND request_status = 'completed'
        LIMIT 1
    `;

    db.query(
        checkRequestSql,
        [userId, service_id],
        (err, requests) => {

            if (err) {
                return res.status(500).json({
                    success: false,
                    message: "Database error",
                    error: err.message
                });
            }

            if (requests.length === 0) {
                return res.status(403).json({
                    success: false,
                    message: "You can review a service only after completing a service request"
                });
            }

            // Check whether user already reviewed this service
            const checkReviewSql = `
                SELECT review_id
                FROM reviews
                WHERE user_id = ?
                AND service_id = ?
            `;

            db.query(
                checkReviewSql,
                [userId, service_id],
                (err, existingReviews) => {

                    if (err) {
                        return res.status(500).json({
                            success: false,
                            message: "Database error",
                            error: err.message
                        });
                    }

                    if (existingReviews.length > 0) {
                        return res.status(409).json({
                            success: false,
                            message: "You have already reviewed this service"
                        });
                    }

                    // Insert review
                    const insertReviewSql = `
                        INSERT INTO reviews
                        (
                            user_id,
                            service_id,
                            rating,
                            comment
                        )
                        VALUES (?, ?, ?, ?)
                    `;

                    db.query(
                        insertReviewSql,
                        [
                            userId,
                            service_id,
                            rating,
                            comment || null
                        ],
                        (err, result) => {

                            if (err) {
                                return res.status(500).json({
                                    success: false,
                                    message: "Failed to add review",
                                    error: err.message
                                });
                            }

                            res.status(201).json({
                                success: true,
                                message: "Review added successfully",
                                review_id: result.insertId
                            });
                        }
                    );
                }
            );
        }
    );
};


// ==========================================
// Get Reviews for a Service
// ==========================================
const getServiceReviews = (req, res) => {

    const serviceId = req.params.serviceId;

    const sql = `
        SELECT
            r.review_id,
            r.rating,
            r.comment,
            r.created_at,
            u.user_id,
            u.name AS user_name
        FROM reviews r

        INNER JOIN users u
            ON r.user_id = u.user_id

        WHERE r.service_id = ?

        ORDER BY r.created_at DESC
    `;

    db.query(
        sql,
        [serviceId],
        (err, results) => {

            if (err) {
                return res.status(500).json({
                    success: false,
                    message: "Failed to fetch reviews",
                    error: err.message
                });
            }

            res.json({
                success: true,
                count: results.length,
                reviews: results
            });
        }
    );
};


// ==========================================
// Get Average Rating
// ==========================================
const getServiceRating = (req, res) => {

    const serviceId = req.params.serviceId;

    const sql = `
        SELECT
            COUNT(review_id) AS total_reviews,
            ROUND(AVG(rating), 1) AS average_rating
        FROM reviews
        WHERE service_id = ?
    `;

    db.query(
        sql,
        [serviceId],
        (err, results) => {

            if (err) {
                return res.status(500).json({
                    success: false,
                    message: "Failed to calculate rating",
                    error: err.message
                });
            }

            res.json({
                success: true,
                service_id: serviceId,
                total_reviews: results[0].total_reviews,
                average_rating: results[0].average_rating || 0
            });
        }
    );
};


module.exports = {
    addReview,
    getServiceReviews,
    getServiceRating
};