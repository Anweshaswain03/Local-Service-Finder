const db = require("../config/db");

// ==========================================
// Get Pending Services
// ==========================================
const getPendingServices = (req, res) => {

    const sql = `
        SELECT
            s.service_id,
            s.service_name,
            s.location,
            s.address,
            s.description,
            s.contact_number,
            s.status,
            s.created_at,
            c.category_name,
            u.user_id AS provider_id,
            u.name AS provider_name,
            u.email AS provider_email
        FROM services s

        INNER JOIN categories c
            ON s.category_id = c.category_id

        INNER JOIN users u
            ON s.provider_id = u.user_id

        WHERE s.status = 'pending'

        ORDER BY s.created_at DESC
    `;

    db.query(sql, (err, results) => {

        if (err) {
            return res.status(500).json({
                success: false,
                message: "Failed to fetch pending services",
                error: err.message
            });
        }

        res.json({
            success: true,
            count: results.length,
            services: results
        });
    });
};


// ==========================================
// Approve Service
// ==========================================
const approveService = (req, res) => {

    const serviceId = req.params.id;

    const sql = `
        UPDATE services
        SET status = 'approved'
        WHERE service_id = ?
    `;

    db.query(sql, [serviceId], (err, result) => {

        if (err) {
            return res.status(500).json({
                success: false,
                message: "Failed to approve service",
                error: err.message
            });
        }

        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: "Service not found"
            });
        }

        res.json({
            success: true,
            message: "Service approved successfully"
        });
    });
};


// ==========================================
// Reject Service
// ==========================================
const rejectService = (req, res) => {

    const serviceId = req.params.id;

    const sql = `
        UPDATE services
        SET status = 'rejected'
        WHERE service_id = ?
    `;

    db.query(sql, [serviceId], (err, result) => {

        if (err) {
            return res.status(500).json({
                success: false,
                message: "Failed to reject service",
                error: err.message
            });
        }

        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: "Service not found"
            });
        }

        res.json({
            success: true,
            message: "Service rejected successfully"
        });
    });
};


// ==========================================
// Get All Users
// ==========================================
const getAllUsers = (req, res) => {

    const sql = `
        SELECT
            user_id,
            name,
            email,
            phone,
            role,
            status,
            created_at
        FROM users
        ORDER BY created_at DESC
    `;

    db.query(sql, (err, results) => {

        if (err) {
            return res.status(500).json({
                success: false,
                message: "Failed to fetch users",
                error: err.message
            });
        }

        res.json({
            success: true,
            count: results.length,
            users: results
        });
    });
};


// ==========================================
// Block User
// ==========================================
const blockUser = (req, res) => {

    const userId = req.params.id;

    // Prevent admin from blocking themselves
    if (Number(userId) === Number(req.user.userId)) {
        return res.status(400).json({
            success: false,
            message: "You cannot block your own admin account"
        });
    }

    const checkUserSql = `
        SELECT user_id, role, status
        FROM users
        WHERE user_id = ?
    `;

    db.query(checkUserSql, [userId], (err, results) => {

        if (err) {
            return res.status(500).json({
                success: false,
                message: "Database error",
                error: err.message
            });
        }

        if (results.length === 0) {
            return res.status(404).json({
                success: false,
                message: "User not found"
            });
        }

        const user = results[0];

        // Prevent blocking another admin
        if (user.role === "admin") {
            return res.status(403).json({
                success: false,
                message: "Admin accounts cannot be blocked"
            });
        }

        const updateSql = `
            UPDATE users
            SET status = 'blocked'
            WHERE user_id = ?
        `;

        db.query(updateSql, [userId], (err, result) => {

            if (err) {
                return res.status(500).json({
                    success: false,
                    message: "Failed to block user",
                    error: err.message
                });
            }

            res.json({
                success: true,
                message: "User blocked successfully"
            });
        });
    });
};

// ==========================================
// Unblock User
// ==========================================
const unblockUser = (req, res) => {

    const userId = req.params.id;

    const sql = `
        UPDATE users
        SET status = 'active'
        WHERE user_id = ?
    `;

    db.query(sql, [userId], (err, result) => {

        if (err) {
            return res.status(500).json({
                success: false,
                message: "User not found or update failed"
            });
        }

        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: "User not found"
            });
        }

        res.json({
            success: true,
            message: "User unblocked successfully"
        });
    });
};
// Get Admin Dashboard Statistics
const getAdminStats = (req, res) => {

    const userStatsSql = `
        SELECT
            COUNT(*) AS total_users,

            SUM(CASE
                WHEN role = 'user' THEN 1
                ELSE 0
            END) AS total_customers,

            SUM(CASE
                WHEN role = 'provider' THEN 1
                ELSE 0
            END) AS total_providers,

            SUM(CASE
                WHEN role = 'admin' THEN 1
                ELSE 0
            END) AS total_admins

        FROM users
    `;

    const serviceStatsSql = `
        SELECT
            COUNT(*) AS total_services,

            SUM(CASE
                WHEN status = 'pending' THEN 1
                ELSE 0
            END) AS pending_services,

            SUM(CASE
                WHEN status = 'approved' THEN 1
                ELSE 0
            END) AS approved_services,

            SUM(CASE
                WHEN status = 'rejected' THEN 1
                ELSE 0
            END) AS rejected_services

        FROM services
    `;

    const requestStatsSql = `
        SELECT
            COUNT(*) AS total_requests,

            SUM(CASE
                WHEN request_status = 'pending' THEN 1
                ELSE 0
            END) AS pending_requests,

            SUM(CASE
                WHEN request_status = 'accepted' THEN 1
                ELSE 0
            END) AS accepted_requests,

            SUM(CASE
                WHEN request_status = 'rejected' THEN 1
                ELSE 0
            END) AS rejected_requests,

            SUM(CASE
                WHEN request_status = 'completed' THEN 1
                ELSE 0
            END) AS completed_requests

        FROM service_requests
    `;

    const reviewStatsSql = `
        SELECT
            COUNT(*) AS total_reviews,
            ROUND(AVG(rating), 1) AS average_rating
        FROM reviews
    `;

    db.query(userStatsSql, (err, userResults) => {

        if (err) {
            return res.status(500).json({
                success: false,
                message: "Failed to fetch user statistics",
                error: err.message
            });
        }

        db.query(serviceStatsSql, (err, serviceResults) => {

            if (err) {
                return res.status(500).json({
                    success: false,
                    message: "Failed to fetch service statistics",
                    error: err.message
                });
            }

            db.query(requestStatsSql, (err, requestResults) => {

                if (err) {
                    return res.status(500).json({
                        success: false,
                        message: "Failed to fetch request statistics",
                        error: err.message
                    });
                }

                db.query(reviewStatsSql, (err, reviewResults) => {

                    if (err) {
                        return res.status(500).json({
                            success: false,
                            message: "Failed to fetch review statistics",
                            error: err.message
                        });
                    }

                    const users = userResults[0];
                    const services = serviceResults[0];
                    const requests = requestResults[0];
                    const reviews = reviewResults[0];

                    res.json({
                        success: true,

                        statistics: {

                            users: {
                                total: Number(users.total_users),
                                customers: Number(users.total_customers),
                                providers: Number(users.total_providers),
                                admins: Number(users.total_admins)
                            },

                            services: {
                                total: Number(services.total_services),
                                pending: Number(services.pending_services),
                                approved: Number(services.approved_services),
                                rejected: Number(services.rejected_services)
                            },

                            requests: {
                                total: Number(requests.total_requests),
                                pending: Number(requests.pending_requests),
                                accepted: Number(requests.accepted_requests),
                                rejected: Number(requests.rejected_requests),
                                completed: Number(requests.completed_requests)
                            },

                            reviews: {
                                total: Number(reviews.total_reviews),
                                average_rating:
                                    Number(reviews.average_rating) || 0
                            }
                        }
                    });
                });
            });
        });
    });
};
module.exports = {
    getPendingServices,
    approveService,
    rejectService,
    getAllUsers,
    blockUser,
    unblockUser,
    getAdminStats
};