const db = require("../config/db");

// ==========================================
// Add New Service
// ==========================================
const addService = (req, res) => {

    const {
        service_name,
        category_id,
        location,
        address,
        description,
        contact_number
    } = req.body;

    // Provider ID comes from JWT
    const providerId = req.user.userId;

    if (!service_name || !category_id || !location) {
        return res.status(400).json({
            success: false,
            message: "Service name, category and location are required"
        });
    }

    // Image is optional
    const image = req.file
        ? `/uploads/${req.file.filename}`
        : null;

    const sql = `
        INSERT INTO services
        (
            provider_id,
            service_name,
            category_id,
            location,
            address,
            description,
            contact_number,
            image
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `;

    db.query(
        sql,
        [
            providerId,
            service_name,
            category_id,
            location,
            address || null,
            description || null,
            contact_number || null,
            image
        ],
        (err, result) => {

            if (err) {
                return res.status(500).json({
                    success: false,
                    message: "Failed to add service",
                    error: err.message
                });
            }

            res.status(201).json({
                success: true,
                message: "Service added successfully",
                service_id: result.insertId,
                image: image
            });
        }
    );
};

// ==========================================
// Get All Approved Services
// ==========================================
const getAllServices = (req, res) => {

    const sql = `
        SELECT
            s.service_id,
            s.service_name,
            s.location,
            s.address,
            s.description,
            s.contact_number,
            s.image,
            s.availability,
            s.status,
            c.category_name,
            u.name AS provider_name
        FROM services s

        INNER JOIN categories c
            ON s.category_id = c.category_id

        INNER JOIN users u
            ON s.provider_id = u.user_id

        WHERE s.status = 'approved'

        ORDER BY s.created_at DESC
    `;

    db.query(sql, (err, results) => {

        if (err) {
            return res.status(500).json({
                success: false,
                message: "Failed to fetch services",
                error: err.message
            });
        }

        res.json({
            success: true,
            count: results.length,
            services: results
        });
    });
};


// ==========================================
// Get Service By ID
// ==========================================
const getServiceById = (req, res) => {

    const serviceId = req.params.id;

    const sql = `
        SELECT
            s.service_id,
            s.service_name,
            s.location,
            s.address,
            s.description,
            s.contact_number,
            s.image,
            s.availability,
            s.status,
            s.created_at,

            c.category_id,
            c.category_name,

            u.user_id AS provider_id,
            u.name AS provider_name,
            u.email AS provider_email,
            u.phone AS provider_phone,

            COUNT(r.review_id) AS total_reviews,
            ROUND(AVG(r.rating), 1) AS average_rating

        FROM services s

        INNER JOIN categories c
            ON s.category_id = c.category_id

        INNER JOIN users u
            ON s.provider_id = u.user_id

        LEFT JOIN reviews r
            ON s.service_id = r.service_id

        WHERE s.service_id = ?

        GROUP BY
            s.service_id,
            s.service_name,
            s.location,
            s.address,
            s.description,
            s.contact_number,
            s.image,
            s.availability,
            s.status,
            s.created_at,
            c.category_id,
            c.category_name,
            u.user_id,
            u.name,
            u.email,
            u.phone
    `;

    db.query(sql, [serviceId], (err, results) => {

        if (err) {
            return res.status(500).json({
                success: false,
                message: "Failed to fetch service details",
                error: err.message
            });
        }

        if (results.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Service not found"
            });
        }

        const service = results[0];

        res.json({
            success: true,
            service: {
                ...service,
                total_reviews: Number(service.total_reviews),
                average_rating: Number(service.average_rating) || 0
            }
        });
    });
};
// ==========================================
// Search and Filter Services
// ==========================================
const searchServices = (req, res) => {

    const {
        search,
        category,
        location
    } = req.query;

    let sql = `
        SELECT
            s.service_id,
            s.service_name,
            s.location,
            s.address,
            s.description,
            s.contact_number,
            s.image,
            s.availability,
            s.status,
            c.category_id,
            c.category_name,
            u.name AS provider_name

        FROM services s

        INNER JOIN categories c
            ON s.category_id = c.category_id

        INNER JOIN users u
            ON s.provider_id = u.user_id

        WHERE s.status = 'approved'
    `;

    const values = [];

    // ==========================================
    // Search by service name / provider / description
    // ==========================================
    if (search && search.trim() !== "") {

        sql += `
            AND (
                s.service_name LIKE ?
                OR u.name LIKE ?
                OR s.description LIKE ?
            )
        `;

        const searchValue = `%${search.trim()}%`;

        values.push(
            searchValue,
            searchValue,
            searchValue
        );
    }

    // ==========================================
    // Filter by category
    // ==========================================
    if (category && category.trim() !== "") {

        if (!isNaN(category)) {

            sql += `
                AND s.category_id = ?
            `;

            values.push(Number(category));

        } else {

            sql += `
                AND c.category_name LIKE ?
            `;

            values.push(`%${category.trim()}%`);
        }
    }

    // ==========================================
    // Filter by location
    // ==========================================
    if (location && location.trim() !== "") {

        sql += `
            AND LOWER(TRIM(s.location)) = LOWER(TRIM(?))
        `;

        values.push(location.trim());
    }

    sql += `
        ORDER BY s.created_at DESC
    `;

    db.query(sql, values, (err, results) => {

        if (err) {

            return res.status(500).json({
                success: false,
                message: "Search failed",
                error: err.message
            });

        }

        res.json({
            success: true,
            count: results.length,
            services: results
        });
    });
};
// ==========================================
// Export Controllers
// ==========================================
module.exports = {
    addService,
    getAllServices,
    getServiceById,
    searchServices
};