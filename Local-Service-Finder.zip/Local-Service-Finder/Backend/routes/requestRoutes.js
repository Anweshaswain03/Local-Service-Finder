const express = require("express");

const {
    createRequest,
    getMyRequests,
    cancelRequest
} = require("../controllers/requestController");

const {
    authenticateToken,
    authorizeRoles
} = require("../middleware/authMiddleware");

const router = express.Router();

// ==========================================
// All customer request routes require login
// ==========================================
router.use(authenticateToken);

// ==========================================
// Create Service Request
// POST /api/requests
// ==========================================
router.post(
    "/",
    authorizeRoles("user"),
    createRequest
);

// ==========================================
// Get My Requests
// GET /api/requests/my-requests
// ==========================================
router.get(
    "/my-requests",
    authorizeRoles("user"),
    getMyRequests
);

// ==========================================
// Cancel Pending Request
// DELETE /api/requests/:id
// ==========================================
router.delete(
    "/:id",
    authorizeRoles("user"),
    cancelRequest
);

module.exports = router;