const express = require("express");

const {
    getPendingServices,
    approveService,
    rejectService,
    getAllUsers,
    blockUser,
    unblockUser,
    getAdminStats
} = require("../controllers/adminController");

const {
    authenticateToken,
    authorizeRoles
} = require("../middleware/authMiddleware");

const router = express.Router();

router.use(authenticateToken);
router.use(authorizeRoles("admin"));

router.get("/stats", getAdminStats);

router.get("/services/pending", getPendingServices);

router.put(
    "/services/:id/approve",
    approveService
);

router.put(
    "/services/:id/reject",
    rejectService
);

router.get("/users", getAllUsers);

router.put(
    "/users/:id/block",
    blockUser
);

router.put(
    "/users/:id/unblock",
    unblockUser
);

module.exports = router;