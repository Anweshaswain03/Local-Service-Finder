const express = require("express");

const {
    getMyServices,
    getProviderStats,
    updateMyService,
    deleteMyService,
    updateAvailability,
    getProviderRequests,
    acceptRequest,
    rejectRequest,
    completeRequest
} = require("../controllers/providerController");

const {
    authenticateToken,
    authorizeRoles
} = require("../middleware/authMiddleware");

const upload = require("../middleware/uploadMiddleware");

const router = express.Router();

// ==========================================
// All provider routes require:
// 1. Valid JWT
// 2. Provider role
// ==========================================
router.use(authenticateToken);
router.use(authorizeRoles("provider"));

router.get("/stats", getProviderStats);
// ==========================================
// Provider Services
// ==========================================

router.get(
    "/my-services",
    getMyServices
);

router.put(
    "/services/:id",
    upload.single("image"),
    updateMyService
);

router.delete(
    "/services/:id",
    deleteMyService
);

router.put(
    "/services/:id/availability",
    updateAvailability
);


// ==========================================
// Provider Service Requests
// ==========================================

// View incoming requests
router.get(
    "/requests",
    getProviderRequests
);

// Accept request
router.put(
    "/requests/:id/accept",
    acceptRequest
);

// Reject request
router.put(
    "/requests/:id/reject",
    rejectRequest
);

// Complete request
router.put(
    "/requests/:id/complete",
    completeRequest
);


module.exports = router;