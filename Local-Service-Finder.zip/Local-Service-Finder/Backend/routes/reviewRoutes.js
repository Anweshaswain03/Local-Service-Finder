const express = require("express");

const {
    addReview,
    getServiceReviews,
    getServiceRating
} = require("../controllers/reviewController");

const {
    authenticateToken,
    authorizeRoles
} = require("../middleware/authMiddleware");

const router = express.Router();

// ==========================================
// Add Review
// ==========================================
router.post(
    "/",
    authenticateToken,
    authorizeRoles("user"),
    addReview
);

// ==========================================
// Get Service Reviews
// ==========================================
router.get(
    "/service/:serviceId",
    getServiceReviews
);

// ==========================================
// Get Service Rating
// ==========================================
router.get(
    "/service/:serviceId/rating",
    getServiceRating
);

module.exports = router;