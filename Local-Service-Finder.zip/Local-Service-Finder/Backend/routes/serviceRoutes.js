const express = require("express");

const {
    addService,
    getAllServices,
    getServiceById,
    searchServices
} = require("../controllers/serviceController");

const {
    authenticateToken,
    authorizeRoles
} = require("../middleware/authMiddleware");

const upload = require("../middleware/uploadMiddleware");

const router = express.Router();


// ==========================================
// Add Service
// ==========================================

router.post(
    "/",
    authenticateToken,
    authorizeRoles("provider"),
    (req, res, next) => {

        upload.single("image")(req, res, (err) => {

            if (err) {

                if (err.code === "LIMIT_FILE_SIZE") {
                    return res.status(400).json({
                        success: false,
                        message: "Image size must not exceed 5 MB"
                    });
                }

                return res.status(400).json({
                    success: false,
                    message: err.message
                });
            }

            next();
        });

    },
    addService
);


// ==========================================
// Get All Services
// ==========================================

router.get("/", getAllServices);


// ==========================================
// Search Services
// ==========================================

router.get("/search", searchServices);


// ==========================================
// Get Service Details
// ==========================================

router.get("/:id", getServiceById);


module.exports = router;