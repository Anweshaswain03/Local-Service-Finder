const API_URL = "http://localhost:5000/api";

const searchInput = document.getElementById("searchInput");
const locationInput = document.getElementById("locationInput");
const categoryFilter = document.getElementById("categoryFilter");
const filterButton = document.getElementById("filterButton");
const clearButton = document.getElementById("clearButton");

const servicesContainer =
    document.getElementById("servicesContainer");

const loadingMessage =
    document.getElementById("loadingMessage");

const errorMessage =
    document.getElementById("errorMessage");

const noResults =
    document.getElementById("noResults");

const resultCount =
    document.getElementById("resultCount");


// ==========================================
// LOAD CATEGORIES
// ==========================================

async function loadCategories() {

    try {

        const response = await fetch(
            `${API_URL}/categories`
        );

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.message);
        }

        data.categories.forEach(category => {

            const option =
                document.createElement("option");

            option.value =
                category.category_id;

            option.textContent =
                category.category_name;

            categoryFilter.appendChild(option);

        });

    } catch (error) {

        console.error(
            "Category loading error:",
            error
        );

    }
}


// ==========================================
// LOAD SERVICES
// ==========================================

async function loadServices() {

    loadingMessage.classList.remove("d-none");

    errorMessage.classList.add("d-none");

    noResults.classList.add("d-none");

    servicesContainer.innerHTML = "";


    const params = new URLSearchParams();


    const search =
        searchInput.value.trim();

    const location =
        locationInput.value.trim();

    const category =
        categoryFilter.value;


    if (search) {
        params.append("search", search);
    }

    if (location) {
        params.append("location", location);
    }

    if (category) {
        params.append("category", category);
    }


    const url =
        `${API_URL}/services/search?${params.toString()}`;


    console.log("Fetching:", url);


    try {

        const response =
            await fetch(url);

        const data =
            await response.json();


        console.log("API Response:", data);


        if (!response.ok) {

            throw new Error(
                data.message ||
                "Failed to load services"
            );

        }


        loadingMessage.classList.add(
            "d-none"
        );


        const services =
            data.services || [];


        resultCount.textContent =
            `${services.length} service${
                services.length !== 1
                    ? "s"
                    : ""
            } found`;


        if (services.length === 0) {

            noResults.classList.remove(
                "d-none"
            );

            return;

        }


        services.forEach(service => {

            createServiceCard(service);

        });


    } catch (error) {

        console.error(
            "Service loading error:",
            error
        );


        loadingMessage.classList.add(
            "d-none"
        );


        errorMessage.textContent =
            error.message ||
            "Unable to load services";


        errorMessage.classList.remove(
            "d-none"
        );

    }

}


// ==========================================
// CREATE SERVICE CARD
// ==========================================

function createServiceCard(service) {

    const col =
        document.createElement("div");

    col.className =
        "col-md-6 col-lg-4";


    let imageHTML;


    if (service.image) {

        imageHTML = `

            <img
                src="http://localhost:5000${service.image}"
                class="service-card-image"
                alt="${escapeHTML(
                    service.service_name
                )}"
                onerror="this.style.display='none'">

        `;

    } else {

        imageHTML = `

            <div class="service-placeholder">

                <i class="bi bi-tools"></i>

            </div>

        `;

    }


    const availability =
        service.availability === "available"

        ? `
            <span class="badge bg-success">
                Available
            </span>
          `

        : `
            <span class="badge bg-secondary">
                Unavailable
            </span>
          `;


    col.innerHTML = `

        <div class="service-card h-100">

            ${imageHTML}


            <div class="service-card-body">


                <div class="d-flex
                            justify-content-between
                            align-items-start
                            mb-2">

                    <span class="category-badge">

                        ${escapeHTML(
                            service.category_name
                        )}

                    </span>


                    ${availability}

                </div>


                <h4 class="service-title">

                    ${escapeHTML(
                        service.service_name
                    )}

                </h4>


                <p class="service-provider">

                    <i class="bi bi-person-circle"></i>

                    ${escapeHTML(
                        service.provider_name
                    )}

                </p>


                <p class="service-location">

                    <i class="bi bi-geo-alt-fill"></i>

                    ${escapeHTML(
                        service.location
                    )}

                </p>


                <p class="service-description">

                    ${escapeHTML(
                        service.description ||
                        "Professional local service."
                    )}

                </p>


                <div class="service-card-footer">


                    <div>

                        <span class="text-warning">

                            <i class="bi bi-star-fill"></i>

                        </span>

                        <span class="fw-semibold">

                            ${service.average_rating
                                || "New"}

                        </span>

                    </div>


                    <a
                        href="service-details.html?id=${service.service_id}"
                        class="btn btn-primary btn-sm">

                        View Details

                        <i class="bi bi-arrow-right"></i>

                    </a>


                </div>

            </div>

        </div>

    `;


    servicesContainer.appendChild(col);

}


// ==========================================
// ESCAPE HTML
// ==========================================

function escapeHTML(value) {

    if (
        value === null ||
        value === undefined
    ) {

        return "";

    }


    return String(value)

        .replaceAll("&", "&amp;")

        .replaceAll("<", "&lt;")

        .replaceAll(">", "&gt;")

        .replaceAll('"', "&quot;")

        .replaceAll("'", "&#039;");

}


// ==========================================
// SEARCH BUTTON
// ==========================================

filterButton.addEventListener(
    "click",
    loadServices
);


// ==========================================
// CLEAR BUTTON
// ==========================================

clearButton.addEventListener(
    "click",
    () => {

        searchInput.value = "";

        locationInput.value = "";

        categoryFilter.value = "";

        loadServices();

    }
);


// ==========================================
// ENTER KEY
// ==========================================

searchInput.addEventListener(
    "keydown",
    event => {

        if (event.key === "Enter") {

            loadServices();

        }

    }
);


locationInput.addEventListener(
    "keydown",
    event => {

        if (event.key === "Enter") {

            loadServices();

        }

    }
);


// ==========================================
// URL FILTERS
// ==========================================

function loadURLFilters() {

    const params =
        new URLSearchParams(
            window.location.search
        );


    const search =
        params.get("search");

    const location =
        params.get("location");

    const category =
        params.get("category");


    if (search) {

        searchInput.value =
            search;

    }


    if (location) {

        locationInput.value =
            location;

    }


    if (category) {

        categoryFilter.value =
            category;

    }

}


// ==========================================
// INITIALIZE
// ==========================================

async function initialize() {

    await loadCategories();

    loadURLFilters();

    await loadServices();

}


initialize();