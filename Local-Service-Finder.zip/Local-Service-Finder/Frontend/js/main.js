// =====================================================
// LOAD COMMON FOOTER ON ALL PAGES
// =====================================================

document.addEventListener("DOMContentLoaded", async () => {

    const footerContainer =
        document.getElementById("footer-container");

    if (!footerContainer) {
        return;
    }

    try {

        const response =
            await fetch("components/footer.html");

        if (!response.ok) {
            throw new Error("Footer could not be loaded");
        }

        footerContainer.innerHTML =
            await response.text();

    } catch (error) {

        console.error("Footer loading error:", error);

    }

});