const API_URL = "http://localhost:5000/api";

const token = localStorage.getItem("token");
const user = JSON.parse(localStorage.getItem("user") || "null");

console.log("ADD SERVICE JS LOADED");
console.log("User:", user);
console.log("Token exists:", !!token);

if (!token || !user || user.role !== "provider") {
    window.location.href = "login.html";
}

const serviceForm = document.getElementById("serviceForm");
const categorySelect = document.getElementById("category");
const successMessage = document.getElementById("successMessage");
const errorMessage = document.getElementById("errorMessage");
const submitButton = document.getElementById("submitButton");

console.log("Form:", serviceForm);
console.log("Category:", categorySelect);
console.log("Button:", submitButton);


// ==========================================
// LOAD CATEGORIES
// ==========================================

async function loadCategories() {

    try {

        const response = await fetch(`${API_URL}/categories`);

        const data = await response.json();

        console.log("Categories:", data);

        if (!response.ok) {
            throw new Error(data.message || "Failed to load categories");
        }

        categorySelect.innerHTML =
            `<option value="">Select Category</option>`;

        data.categories.forEach(category => {

            const option = document.createElement("option");

            option.value = category.category_id;

            option.textContent = category.category_name;

            categorySelect.appendChild(option);

        });

    } catch (error) {

        console.error("Category Error:", error);

        categorySelect.innerHTML =
            `<option value="">Unable to load categories</option>`;
    }
}


// ==========================================
// FORM SUBMIT
// ==========================================

serviceForm.addEventListener("submit", async function (event) {

    event.preventDefault();

    console.log("=================================");
    console.log("SUBMIT BUTTON CLICKED");
    console.log("=================================");


    // Check HTML validation manually
    if (!serviceForm.checkValidity()) {

        console.log("FORM VALIDATION FAILED");

        serviceForm.reportValidity();

        return;
    }


    successMessage.classList.add("d-none");
    errorMessage.classList.add("d-none");

    submitButton.disabled = true;

    submitButton.innerHTML =
        `<span class="spinner-border spinner-border-sm me-2"></span>
         Adding Service...`;


    try {

        const serviceName =
            document.getElementById("serviceName").value.trim();

        const category =
            categorySelect.value;

        const location =
            document.getElementById("location").value.trim();

        const address =
            document.getElementById("address").value.trim();

        const description =
            document.getElementById("description").value.trim();

        const contactNumber =
            document.getElementById("contactNumber").value.trim();


        console.log("Service Name:", serviceName);
        console.log("Category:", category);
        console.log("Location:", location);
        console.log("Address:", address);
        console.log("Description:", description);
        console.log("Contact:", contactNumber);


        const formData = new FormData();

        formData.append("service_name", serviceName);
        formData.append("category_id", category);
        formData.append("location", location);
        formData.append("address", address);
        formData.append("description", description);
        formData.append("contact_number", contactNumber);


        const imageInput =
            document.getElementById("serviceImage");

        if (imageInput.files.length > 0) {

            formData.append(
                "image",
                imageInput.files[0]
            );

            console.log(
                "Image:",
                imageInput.files[0].name
            );
        }


        console.log("Sending POST request...");


        const response = await fetch(
            `${API_URL}/services`,
            {
                method: "POST",

                headers: {
                    Authorization: `Bearer ${token}`
                },

                body: formData
            }
        );


        console.log(
            "POST STATUS:",
            response.status
        );


        const data = await response.json();


        console.log(
            "SERVER RESPONSE:",
            data
        );


        if (!response.ok) {

            throw new Error(
                data.message ||
                "Failed to add service"
            );
        }


        successMessage.textContent =
            data.message ||
            "Service added successfully. Waiting for admin approval.";

        successMessage.classList.remove("d-none");


        serviceForm.reset();


        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });


    } catch (error) {

        console.error(
            "ADD SERVICE ERROR:",
            error
        );


        errorMessage.textContent =
            error.message ||
            "Unable to add service.";

        errorMessage.classList.remove("d-none");


    } finally {

        submitButton.disabled = false;

        submitButton.innerHTML =
            `<i class="bi bi-plus-circle me-2"></i>
             Add Service`;
    }

});


// ==========================================
// INITIALIZE
// ==========================================

loadCategories();