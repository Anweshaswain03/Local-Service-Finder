const API_URL = "http://localhost:5000/api";


// ======================================================
// AUTHENTICATION
// ======================================================

const token = localStorage.getItem("token");

const user = JSON.parse(
    localStorage.getItem("user") || "null"
);


console.log("Admin User:", user);


if (
    !token ||
    !user ||
    user.role !== "admin"
) {

    window.location.href = "login.html";

}


// ======================================================
// ELEMENTS
// ======================================================

const adminName =
    document.getElementById("adminName");

const errorMessage =
    document.getElementById("errorMessage");


// Statistics

const totalUsers =
    document.getElementById("totalUsers");

const totalProviders =
    document.getElementById("totalProviders");

const totalServices =
    document.getElementById("totalServices");

const pendingServices =
    document.getElementById("pendingServices");


// Services

const servicesLoading =
    document.getElementById("servicesLoading");

const noPendingServices =
    document.getElementById("noPendingServices");

const pendingServicesContainer =
    document.getElementById(
        "pendingServicesContainer"
    );


// Users

const usersLoading =
    document.getElementById("usersLoading");

const usersTable =
    document.getElementById("usersTable");

const usersTableBody =
    document.getElementById("usersTableBody");


// ======================================================
// ADMIN NAME
// ======================================================

adminName.textContent =
    user.name || "Admin";


// ======================================================
// ERROR
// ======================================================

function showError(message) {

    errorMessage.textContent = message;

    errorMessage.classList.remove(
        "d-none"
    );

}


function hideError() {

    errorMessage.classList.add(
        "d-none"
    );

}


// ======================================================
// LOAD ADMIN STATISTICS
// ======================================================

async function loadStatistics() {

    try {

        const response = await fetch(
            `${API_URL}/admin/stats`,
            {
                headers: {
                    Authorization:
                        `Bearer ${token}`
                }
            }
        );


        const data =
            await response.json();


        console.log(
            "Admin Stats:",
            data
        );


        if (!response.ok) {

            throw new Error(
                data.message ||
                "Failed to load statistics"
            );

        }


        /*
           The backend may return:

           data.statistics

           or

           data.stats
        */

        const stats =
            data.statistics ||
            data.stats ||
            data;


        totalUsers.textContent =
            stats.users?.total ??
            stats.totalUsers ??
            0;


        totalProviders.textContent =
            stats.providers?.total ??
            stats.totalProviders ??
            0;


        totalServices.textContent =
            stats.services?.total ??
            stats.totalServices ??
            0;


        pendingServices.textContent =
            stats.services?.pending ??
            stats.pendingServices ??
            0;


    } catch (error) {

        console.error(
            "Statistics Error:",
            error
        );

        showError(error.message);

    }

}


// ======================================================
// LOAD PENDING SERVICES
// ======================================================

async function loadPendingServices() {

    servicesLoading.classList.remove(
        "d-none"
    );

    noPendingServices.classList.add(
        "d-none"
    );

    pendingServicesContainer.innerHTML =
        "";


    try {

        const response = await fetch(
            `${API_URL}/admin/services/pending`,
            {
                headers: {
                    Authorization:
                        `Bearer ${token}`
                }
            }
        );


        const data =
            await response.json();


        console.log(
            "Pending Services:",
            data
        );


        if (!response.ok) {

            throw new Error(
                data.message ||
                "Failed to load pending services"
            );

        }


        servicesLoading.classList.add(
            "d-none"
        );


        const services =
            data.services ||
            data.pendingServices ||
            [];


        if (services.length === 0) {

            noPendingServices.classList.remove(
                "d-none"
            );

            return;

        }


        services.forEach(
            createPendingServiceCard
        );


    } catch (error) {

        console.error(
            "Pending Services Error:",
            error
        );

        servicesLoading.classList.add(
            "d-none"
        );

        showError(error.message);

    }

}


// ======================================================
// CREATE SERVICE CARD
// ======================================================

function createPendingServiceCard(service) {

    const col =
        document.createElement("div");

    col.className =
        "col-md-6 col-xl-4";


    let imageHTML;


    if (service.image) {

        imageHTML = `
            <img
                src="http://localhost:5000${service.image}"
                class="provider-service-image"
                alt="${escapeHTML(
                    service.service_name
                )}"
                onerror="this.style.display='none'"
            >
        `;

    } else {

        imageHTML = `
            <div
                class="provider-service-placeholder">

                <i class="bi bi-tools"></i>

            </div>
        `;

    }


    col.innerHTML = `

        <div class="dashboard-section-card h-100">

            ${imageHTML}

            <div class="pt-3">

                <span
                    class="badge bg-warning text-dark mb-2">

                    Pending Approval

                </span>


                <h5 class="fw-bold">

                    ${escapeHTML(
                        service.service_name ||
                        "Service"
                    )}

                </h5>


                <p class="mb-1">

                    <i
                        class="bi bi-person me-1">
                    </i>

                    ${escapeHTML(
                        service.provider_name ||
                        service.name ||
                        "Unknown Provider"
                    )}

                </p>


                <p class="mb-1 text-muted">

                    <i
                        class="bi bi-tag me-1">
                    </i>

                    ${escapeHTML(
                        service.category_name ||
                        "Category"
                    )}

                </p>


                <p class="mb-2 text-muted">

                    <i
                        class="bi bi-geo-alt me-1">
                    </i>

                    ${escapeHTML(
                        service.location ||
                        "Location not available"
                    )}

                </p>


                <p class="small text-muted">

                    ${escapeHTML(
                        service.description ||
                        "No description provided."
                    )}

                </p>


                <div class="d-flex gap-2 mt-3">

                    <button
                        class="btn btn-success btn-sm flex-fill"
                        onclick="approveService(
                            ${service.service_id}
                        )">

                        <i
                            class="bi bi-check-lg me-1">
                        </i>

                        Approve

                    </button>


                    <button
                        class="btn btn-danger btn-sm flex-fill"
                        onclick="rejectService(
                            ${service.service_id}
                        )">

                        <i
                            class="bi bi-x-lg me-1">
                        </i>

                        Reject

                    </button>

                </div>

            </div>

        </div>
    `;


    pendingServicesContainer.appendChild(
        col
    );

}


// ======================================================
// APPROVE SERVICE
// ======================================================

async function approveService(serviceId) {

    if (
        !confirm(
            "Are you sure you want to approve this service?"
        )
    ) {
        return;
    }


    try {

        const response = await fetch(
            `${API_URL}/admin/services/${serviceId}/approve`,
            {
                method: "PUT",

                headers: {
                    Authorization:
                        `Bearer ${token}`
                }
            }
        );


        const data =
            await response.json();


        console.log(
            "Approve Response:",
            data
        );


        if (!response.ok) {

            throw new Error(
                data.message ||
                "Failed to approve service"
            );

        }


        alert(
            data.message ||
            "Service approved successfully."
        );


        loadPendingServices();

        loadStatistics();


    } catch (error) {

        console.error(
            "Approve Error:",
            error
        );

        showError(error.message);

    }

}


// ======================================================
// REJECT SERVICE
// ======================================================

async function rejectService(serviceId) {

    if (
        !confirm(
            "Are you sure you want to reject this service?"
        )
    ) {
        return;
    }


    try {

        const response = await fetch(
            `${API_URL}/admin/services/${serviceId}/reject`,
            {
                method: "PUT",

                headers: {
                    Authorization:
                        `Bearer ${token}`
                }
            }
        );


        const data =
            await response.json();


        console.log(
            "Reject Response:",
            data
        );


        if (!response.ok) {

            throw new Error(
                data.message ||
                "Failed to reject service"
            );

        }


        alert(
            data.message ||
            "Service rejected successfully."
        );


        loadPendingServices();

        loadStatistics();


    } catch (error) {

        console.error(
            "Reject Error:",
            error
        );

        showError(error.message);

    }

}


// ======================================================
// LOAD USERS
// ======================================================

async function loadUsers() {

    usersLoading.classList.remove(
        "d-none"
    );

    usersTable.classList.add(
        "d-none"
    );


    try {

        const response = await fetch(
            `${API_URL}/admin/users`,
            {
                headers: {
                    Authorization:
                        `Bearer ${token}`
                }
            }
        );


        const data =
            await response.json();


        console.log(
            "Users:",
            data
        );


        if (!response.ok) {

            throw new Error(
                data.message ||
                "Failed to load users"
            );

        }


        const users =
            data.users ||
            [];


        usersTableBody.innerHTML =
            "";


        users.forEach(
            createUserRow
        );


        usersLoading.classList.add(
            "d-none"
        );

        usersTable.classList.remove(
            "d-none"
        );


    } catch (error) {

        console.error(
            "Users Error:",
            error
        );

        usersLoading.classList.add(
            "d-none"
        );

        showError(error.message);

    }

}


// ======================================================
// CREATE USER ROW
// ======================================================

function createUserRow(userData) {

    const row =
        document.createElement("tr");


    const roleBadge =
        userData.role === "admin"
            ? "bg-danger"
            : userData.role === "provider"
                ? "bg-success"
                : "bg-primary";


    const statusBadge =
        userData.status === "active"
            ? "bg-success"
            : "bg-secondary";


    const isCurrentAdmin =
        Number(userData.user_id) ===
        Number(user.user_id);


    let actionHTML = "";


    if (
        userData.role === "admin"
    ) {

        actionHTML = `
            <span class="text-muted small">
                Admin
            </span>
        `;

    } else if (userData.status === "active") {

        actionHTML = `

            <button
                class="btn btn-outline-danger btn-sm"
                onclick="toggleUserStatus(
                    ${userData.user_id},
                    'block'
                )">

                <i
                    class="bi bi-slash-circle me-1">
                </i>

                Block

            </button>

        `;

    } else {

        actionHTML = `

            <button
                class="btn btn-outline-success btn-sm"
                onclick="toggleUserStatus(
                    ${userData.user_id},
                    'unblock'
                )">

                <i
                    class="bi bi-check-circle me-1">
                </i>

                Unblock

            </button>

        `;

    }


    row.innerHTML = `

        <td>
            ${userData.user_id}
        </td>

        <td class="fw-semibold">
            ${escapeHTML(
                userData.name
            )}
        </td>

        <td>
            ${escapeHTML(
                userData.email
            )}
        </td>

        <td>
            ${escapeHTML(
                userData.phone ||
                "-"
            )}
        </td>

        <td>

            <span
                class="badge ${roleBadge}">

                ${escapeHTML(
                    userData.role
                )}

            </span>

        </td>

        <td>

            <span
                class="badge ${statusBadge}">

                ${escapeHTML(
                    userData.status
                )}

            </span>

        </td>

        <td>

            ${actionHTML}

        </td>
    `;


    usersTableBody.appendChild(
        row
    );

}


// ======================================================
// BLOCK / UNBLOCK USER
// ======================================================

async function toggleUserStatus(
    userId,
    action
) {

    const message =
        action === "block"
            ? "Are you sure you want to block this user?"
            : "Unblock this user?";


    if (!confirm(message)) {
        return;
    }


    try {

        const response = await fetch(
            `${API_URL}/admin/users/${userId}/${action}`,
            {
                method: "PUT",

                headers: {
                    Authorization:
                        `Bearer ${token}`
                }
            }
        );


        const data =
            await response.json();


        console.log(
            "User Status Response:",
            data
        );


        if (!response.ok) {

            throw new Error(
                data.message ||
                "Failed to update user status"
            );

        }


        alert(
            data.message ||
            "User status updated."
        );


        loadUsers();

        loadStatistics();


    } catch (error) {

        console.error(
            "User Status Error:",
            error
        );

        showError(error.message);

    }

}


// ======================================================
// ESCAPE HTML
// ======================================================

function escapeHTML(value) {

    if (
        value === null ||
        value === undefined
    ) {
        return "";
    }


    return String(value)

        .replaceAll(
            "&",
            "&amp;"
        )

        .replaceAll(
            "<",
            "&lt;"
        )

        .replaceAll(
            ">",
            "&gt;"
        )

        .replaceAll(
            '"',
            "&quot;"
        )

        .replaceAll(
            "'",
            "&#039;"
        );

}


// ======================================================
// LOGOUT
// ======================================================

document
    .getElementById("logoutButton")
    .addEventListener(
        "click",
        function () {

            localStorage.removeItem(
                "token"
            );

            localStorage.removeItem(
                "user"
            );

            window.location.href =
                "login.html";

        }
    );


// ======================================================
// REFRESH BUTTONS
// ======================================================

document
    .getElementById(
        "refreshServicesButton"
    )
    .addEventListener(
        "click",
        function () {

            loadPendingServices();

            loadStatistics();

        }
    );


document
    .getElementById(
        "refreshUsersButton"
    )
    .addEventListener(
        "click",
        function () {

            loadUsers();

        }
    );


// ======================================================
// INITIALIZE
// ======================================================

async function initializeAdminDashboard() {

    hideError();

    await loadStatistics();

    await loadPendingServices();

    await loadUsers();

}


initializeAdminDashboard();