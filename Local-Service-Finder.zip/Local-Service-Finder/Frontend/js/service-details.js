const API_URL =
    "http://localhost:5000/api";


// ==========================================
// GET SERVICE ID FROM URL
// ==========================================

const urlParams =
    new URLSearchParams(
        window.location.search
    );

const serviceId =
    urlParams.get("id");


// ==========================================
// ELEMENTS
// ==========================================

const detailsLoading =
    document.getElementById(
        "detailsLoading"
    );

const detailsError =
    document.getElementById(
        "detailsError"
    );

const errorText =
    document.getElementById(
        "errorText"
    );

const serviceDetailsSection =
    document.getElementById(
        "serviceDetailsSection"
    );

const serviceImageContainer =
    document.getElementById(
        "serviceImageContainer"
    );

const serviceName =
    document.getElementById(
        "serviceName"
    );

const serviceCategory =
    document.getElementById(
        "serviceCategory"
    );

const serviceAvailability =
    document.getElementById(
        "serviceAvailability"
    );

const providerName =
    document.getElementById(
        "providerName"
    );

const serviceLocation =
    document.getElementById(
        "serviceLocation"
    );

const serviceAddress =
    document.getElementById(
        "serviceAddress"
    );

const serviceContact =
    document.getElementById(
        "serviceContact"
    );

const serviceDescription =
    document.getElementById(
        "serviceDescription"
    );

const averageRating =
    document.getElementById(
        "averageRating"
    );

const totalReviews =
    document.getElementById(
        "totalReviews"
    );

const callButton =
    document.getElementById(
        "callButton"
    );

const requestServiceButton =
    document.getElementById(
        "requestServiceButton"
    );

const reviewsContainer =
    document.getElementById(
        "reviewsContainer"
    );

const noReviews =
    document.getElementById(
        "noReviews"
    );

const reviewCountBadge =
    document.getElementById(
        "reviewCountBadge"
    );


// ==========================================
// LOAD SERVICE DETAILS
// ==========================================

async function loadServiceDetails() {

    if (!serviceId) {

        showError(
            "No service ID was provided."
        );

        return;

    }


    try {

        const response =
            await fetch(
                `${API_URL}/services/${serviceId}`
            );


        const data =
            await response.json();


        if (!response.ok) {

            throw new Error(
                data.message ||
                "Failed to load service."
            );

        }


        displayService(
            data.service
        );


        await loadReviews();


        detailsLoading.classList.add(
            "d-none"
        );

        serviceDetailsSection.classList.remove(
            "d-none"
        );


    } catch (error) {

        console.error(error);

        showError(
            error.message ||
            "Unable to load service details."
        );

    }

}


// ==========================================
// DISPLAY SERVICE
// ==========================================

function displayService(service) {


    serviceName.textContent =
        service.service_name;


    serviceCategory.textContent =
        service.category_name;


    providerName.textContent =
        service.provider_name;


    serviceLocation.textContent =
        service.location;


    serviceAddress.textContent =
        service.address ||
        "Address not available";


    serviceContact.textContent =
        service.contact_number ||
        "Contact number not available";


    serviceDescription.textContent =
        service.description ||
        "No description available.";


    // Availability

    if (
        service.availability ===
        "available"
    ) {

        serviceAvailability.innerHTML = `

            <span class="badge bg-success">

                <i class="bi bi-check-circle-fill me-1"></i>

                Available

            </span>

        `;

        requestServiceButton.disabled =
            false;

    } else {

        serviceAvailability.innerHTML = `

            <span class="badge bg-secondary">

                <i class="bi bi-x-circle-fill me-1"></i>

                Unavailable

            </span>

        `;

        requestServiceButton.disabled =
            true;

    }


    // Image

    if (service.image) {

        serviceImageContainer.innerHTML = `

            <img
                src="http://localhost:5000${service.image}"
                class="details-service-image"
                alt="${escapeHTML(
                    service.service_name
                )}">

        `;

    } else {

        serviceImageContainer.innerHTML = `

            <div class="details-placeholder">

                <i class="bi bi-tools"></i>

            </div>

        `;

    }


    // Rating

    const rating =
        Number(
            service.average_rating
        ) || 0;


    if (rating > 0) {

        averageRating.textContent =
            rating.toFixed(1);

        totalReviews.textContent =
            `${service.total_reviews} review${
                service.total_reviews !== 1
                    ? "s"
                    : ""
            }`;

    } else {

        averageRating.textContent =
            "New";

        totalReviews.textContent =
            "No reviews yet";

    }


    // Call button

    if (service.contact_number) {

        callButton.href =
            `tel:${service.contact_number}`;

    } else {

        callButton.classList.add(
            "disabled"
        );

    }

}


// ==========================================
// LOAD REVIEWS
// ==========================================

async function loadReviews() {

    try {

        const response =
            await fetch(
                `${API_URL}/reviews/service/${serviceId}`
            );


        const data =
            await response.json();


        if (!response.ok) {

            throw new Error(
                data.message ||
                "Failed to load reviews."
            );

        }


        const reviews =
            data.reviews || [];


        reviewsContainer.innerHTML =
            "";


        reviewCountBadge.textContent =
            `${reviews.length} Review${
                reviews.length !== 1
                    ? "s"
                    : ""
            }`;


        if (reviews.length === 0) {

            noReviews.classList.remove(
                "d-none"
            );

            return;

        }


        noReviews.classList.add(
            "d-none"
        );


        reviews.forEach(
            review => {

                createReviewCard(
                    review
                );

            }
        );


    } catch (error) {

        console.error(
            "Review loading error:",
            error
        );

        noReviews.classList.remove(
            "d-none"
        );

    }

}


// ==========================================
// CREATE REVIEW CARD
// ==========================================

function createReviewCard(review) {

    const div =
        document.createElement("div");


    div.className =
        "review-item";


    const rating =
        Number(review.rating) || 0;


    let stars = "";


    for (
        let i = 1;
        i <= 5;
        i++
    ) {

        stars +=
            i <= rating

                ? `<i class="bi bi-star-fill text-warning"></i>`

                : `<i class="bi bi-star text-muted"></i>`;

    }


    div.innerHTML = `

        <div class="d-flex
                    justify-content-between
                    align-items-start">

            <div>

                <h6 class="fw-bold mb-1">

                    ${escapeHTML(
                        review.user_name ||
                        "Customer"
                    )}

                </h6>


                <div class="mb-2">

                    ${stars}

                </div>

            </div>


            <small class="text-muted">

                ${formatDate(
                    review.created_at
                )}

            </small>

        </div>


        <p class="text-muted mb-0">

            ${escapeHTML(
                review.comment ||
                "No comment provided."
            )}

        </p>

    `;


    reviewsContainer.appendChild(
        div
    );

}


// ==========================================
// REQUEST SERVICE
// ==========================================

requestServiceButton.addEventListener(
    "click",
    () => {

        const token =
            localStorage.getItem(
                "token"
            );


        const user =
            JSON.parse(
                localStorage.getItem(
                    "user"
                ) || "null"
            );


        if (!token || !user) {

            window.location.href =
                "login.html";

            return;

        }


        if (user.role !== "user") {

            alert(
                "Only customer accounts can request a service."
            );

            return;

        }


        const modal =
            new bootstrap.Modal(
                document.getElementById(
                    "requestModal"
                )
            );


        modal.show();

    }
);


// ==========================================
// SEND REQUEST
// ==========================================

document
    .getElementById(
        "sendRequestButton"
    )
    .addEventListener(
        "click",
        sendServiceRequest
    );


async function sendServiceRequest() {

    const token =
        localStorage.getItem(
            "token"
        );


    const message =
        document
            .getElementById(
                "requestText"
            )
            .value
            .trim();


    const messageBox =
        document.getElementById(
            "modalRequestMessage"
        );


    if (!message) {

        messageBox.className =
            "alert alert-warning";

        messageBox.textContent =
            "Please enter a message.";

        return;

    }


    try {

        const response =
            await fetch(
                `${API_URL}/requests`,
                {
                    method: "POST",

                    headers: {
                        "Content-Type":
                            "application/json",

                        "Authorization":
                            `Bearer ${token}`
                    },

                    body: JSON.stringify({

                        service_id:
                            Number(serviceId),

                        message:
                            message

                    })

                }
            );


        const data =
            await response.json();


        if (!response.ok) {

            throw new Error(
                data.message ||
                "Request failed."
            );

        }


        messageBox.className =
            "alert alert-success";

        messageBox.textContent =
            "Service request sent successfully!";


        document
            .getElementById(
                "requestText"
            )
            .value = "";


        setTimeout(() => {

            window.location.href =
                "services.html";

        }, 1200);


    } catch (error) {

        console.error(error);


        messageBox.className =
            "alert alert-danger";

        messageBox.textContent =
            error.message ||
            "Unable to send request.";

    }

}


// ==========================================
// ERROR
// ==========================================

function showError(message) {

    detailsLoading.classList.add(
        "d-none"
    );

    serviceDetailsSection.classList.add(
        "d-none"
    );

    errorText.textContent =
        message;

    detailsError.classList.remove(
        "d-none"
    );

}


// ==========================================
// FORMAT DATE
// ==========================================

function formatDate(date) {

    if (!date) {
        return "";
    }


    const d =
        new Date(date);


    return d.toLocaleDateString(
        "en-IN",
        {
            day: "2-digit",
            month: "short",
            year: "numeric"
        }
    );

}


// ==========================================
// ESCAPE HTML
// ==========================================

function escapeHTML(value) {

    if (
        value === null ||
        value === undefined
    ) {

        return "";

    }


    return String(value)
        .replaceAll(
            "&",
            "&amp;"
        )
        .replaceAll(
            "<",
            "&lt;"
        )
        .replaceAll(
            ">",
            "&gt;"
        )
        .replaceAll(
            '"',
            "&quot;"
        )
        .replaceAll(
            "'",
            "&#039;"
        );

}


// ==========================================
// START
// ==========================================

loadServiceDetails();