const API_URL =
    "http://localhost:5000/api";


// ==========================================
// AUTH CHECK
// ==========================================

const token =
    localStorage.getItem("token");

const user =
    JSON.parse(
        localStorage.getItem("user") || "null"
    );


if (
    !token ||
    !user ||
    user.role !== "provider"
) {

    window.location.href =
        "login.html";

}


// ==========================================
// ELEMENTS
// ==========================================

const providerName =
    document.getElementById(
        "providerName"
    );

const providerNavbarName =
    document.getElementById(
        "providerNavbarName"
    );

const totalServices =
    document.getElementById(
        "totalServices"
    );

const availableServices =
    document.getElementById(
        "availableServices"
    );

const pendingRequests =
    document.getElementById(
        "pendingRequests"
    );

const providerServices =
    document.getElementById(
        "providerServices"
    );

const servicesLoading =
    document.getElementById(
        "servicesLoading"
    );

const servicesError =
    document.getElementById(
        "servicesError"
    );

const noProviderServices =
    document.getElementById(
        "noProviderServices"
    );

const requestsContainer =
    document.getElementById(
        "requestsContainer"
    );

const requestsLoading =
    document.getElementById(
        "requestsLoading"
    );

const noRequests =
    document.getElementById(
        "noRequests"
    );


// ==========================================
// DISPLAY PROVIDER
// ==========================================

providerName.textContent =
    user.name;

providerNavbarName.textContent =
    user.name;


// ==========================================
// LOAD STATS
// ==========================================

async function loadStats() {
    try {
        const response = await fetch(`${API_URL}/provider/stats`, {
            headers: {
                Authorization: `Bearer ${localStorage.getItem("token")}`
            }
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.message || "Failed to load statistics");
        }

        console.log("Provider Statistics:", data);

        const statistics = data.statistics;

        // Service statistics
        document.getElementById("totalServices").textContent =
            statistics.services.total;

        document.getElementById("availableServices").textContent =
            statistics.services.available;

        // Pending customer requests
        document.getElementById("pendingRequests").textContent =
            statistics.requests.pending;

    } catch (error) {
        console.error("Stats loading error:", error);
    }
}

// ==========================================
// LOAD MY SERVICES
// ==========================================

async function loadMyServices() {

    servicesLoading.classList.remove(
        "d-none"
    );

    servicesError.classList.add(
        "d-none"
    );

    noProviderServices.classList.add(
        "d-none"
    );

    providerServices.innerHTML =
        "";


    try {

        const response =
            await fetch(
                `${API_URL}/provider/my-services`,
                {
                    headers: {
                        Authorization:
                            `Bearer ${token}`
                    }
                }
            );


        const data =
            await response.json();


        if (!response.ok) {

            throw new Error(
                data.message ||
                "Failed to load services"
            );

        }


        servicesLoading.classList.add(
            "d-none"
        );


        const services =
            data.services || [];


        if (services.length === 0) {

            noProviderServices.classList.remove(
                "d-none"
            );

            return;

        }


        services.forEach(
            service => {

                createProviderServiceCard(
                    service
                );

            }
        );


    } catch (error) {

        console.error(error);


        servicesLoading.classList.add(
            "d-none"
        );


        servicesError.textContent =
            error.message;


        servicesError.classList.remove(
            "d-none"
        );

    }

}


// ==========================================
// CREATE SERVICE CARD
// ==========================================

function createProviderServiceCard(
    service
) {

    const col =
        document.createElement("div");

    col.className =
        "col-md-6 col-lg-4";


    const imageHTML =
        service.image

            ? `
                <img
                    src="http://localhost:5000${service.image}"
                    class="provider-service-image"
                    alt="${escapeHTML(
                        service.service_name
                    )}">
              `

            : `
                <div class="provider-service-placeholder">

                    <i class="bi bi-tools"></i>

                </div>
              `;


    const availability =
        service.availability === "available"

            ? `
                <span class="badge bg-success">
                    Available
                </span>
              `

            : `
                <span class="badge bg-secondary">
                    Unavailable
                </span>
              `;


    const statusClass =
        service.status === "approved"

            ? "bg-success"

            : service.status === "pending"

                ? "bg-warning text-dark"

                : "bg-danger";


    col.innerHTML = `

        <div class="provider-service-card h-100">

            ${imageHTML}


            <div class="p-3">


                <div class="d-flex
                            justify-content-between
                            align-items-start
                            gap-2
                            mb-2">

                    <span class="category-badge">

                        ${escapeHTML(
                            service.category_name
                        )}

                    </span>


                    ${availability}

                </div>


                <h5 class="fw-bold">

                    ${escapeHTML(
                        service.service_name
                    )}

                </h5>


                <p class="text-muted small mb-2">

                    <i class="bi bi-geo-alt-fill text-primary"></i>

                    ${escapeHTML(
                        service.location
                    )}

                </p>


                <p class="text-muted small">

                    ${escapeHTML(
                        service.description ||
                        "No description"
                    )}

                </p>


                <div class="mb-3">

                    <span
                        class="badge ${statusClass}">

                        ${escapeHTML(
                            service.status
                        )}

                    </span>

                </div>


                <div class="d-flex gap-2">

                    <button
                        class="btn btn-outline-primary btn-sm flex-fill"
                        onclick="toggleAvailability(
                            ${service.service_id},
                            '${service.availability}'
                        )">

                        <i class="bi bi-power"></i>

                        ${service.availability === "available"
                            ? "Mark Unavailable"
                            : "Mark Available"}

                    </button>

                </div>

            </div>

        </div>

    `;


    providerServices.appendChild(
        col
    );

}


// ==========================================
// TOGGLE AVAILABILITY
// ==========================================

async function toggleAvailability(
    serviceId,
    currentAvailability
) {

    const newAvailability =
        currentAvailability === "available"
            ? "unavailable"
            : "available";


    try {

        const response =
            await fetch(
                `${API_URL}/provider/services/${serviceId}/availability`,
                {
                    method: "PUT",

                    headers: {
                        "Content-Type":
                            "application/json",

                        Authorization:
                            `Bearer ${token}`
                    },

                    body: JSON.stringify({
                        availability:
                            newAvailability
                    })

                }
            );


        const data =
            await response.json();


        if (!response.ok) {

            throw new Error(
                data.message ||
                "Failed to update availability"
            );

        }


        await loadMyServices();

        await loadStats();


    } catch (error) {

        alert(
            error.message
        );

    }

}


// ==========================================
// LOAD CUSTOMER REQUESTS
// ==========================================

async function loadRequests() {

    requestsLoading.classList.remove(
        "d-none"
    );

    noRequests.classList.add(
        "d-none"
    );

    requestsContainer.innerHTML =
        "";


    try {

        const response =
            await fetch(
                `${API_URL}/provider/requests`,
                {
                    headers: {
                        Authorization:
                            `Bearer ${token}`
                    }
                }
            );


        const data =
            await response.json();


        if (!response.ok) {

            throw new Error(
                data.message ||
                "Failed to load requests"
            );

        }


        requestsLoading.classList.add(
            "d-none"
        );


        const requests =
            data.requests || [];


        if (requests.length === 0) {

            noRequests.classList.remove(
                "d-none"
            );

            return;

        }


        requests.forEach(
            request => {

                createRequestCard(
                    request
                );

            }
        );


    } catch (error) {

        console.error(
            "Request error:",
            error
        );

        requestsLoading.classList.add(
            "d-none"
        );

        requestsContainer.innerHTML = `

            <div class="alert alert-danger">

                ${escapeHTML(
                    error.message
                )}

            </div>

        `;

    }

}


// ==========================================
// CREATE REQUEST CARD
// ==========================================

function createRequestCard(
    request
) {

    const div =
        document.createElement("div");


    div.className =
        "provider-request-card";


    let actionButtons = "";


    if (
        request.request_status ===
        "pending"
    ) {

        actionButtons = `

            <button
                class="btn btn-success btn-sm"
                onclick="updateRequest(
                    ${request.request_id},
                    'accept'
                )">

                <i class="bi bi-check-lg"></i>

                Accept

            </button>


            <button
                class="btn btn-outline-danger btn-sm"
                onclick="updateRequest(
                    ${request.request_id},
                    'reject'
                )">

                <i class="bi bi-x-lg"></i>

                Reject

            </button>

        `;

    }


    if (
        request.request_status ===
        "accepted"
    ) {

        actionButtons = `

            <button
                class="btn btn-primary btn-sm"
                onclick="updateRequest(
                    ${request.request_id},
                    'complete'
                )">

                <i class="bi bi-check-circle"></i>

                Mark Completed

            </button>

        `;

    }


    div.innerHTML = `

        <div
            class="d-flex
                   justify-content-between
                   align-items-start
                   flex-wrap
                   gap-3">


            <div>

                <h5 class="fw-bold mb-1">

                    ${escapeHTML(
                        request.service_name
                    )}

                </h5>


                <p class="mb-1">

                    <i class="bi bi-person-circle text-primary"></i>

                    ${escapeHTML(
                        request.user_name
                    )}

                </p>


                <p class="text-muted small mb-2">

                    ${escapeHTML(
                        request.user_email
                    )}

                </p>


                <p class="mb-0 text-muted">

                    ${escapeHTML(
                        request.message ||
                        "No message provided."
                    )}

                </p>

            </div>


            <div class="text-end">

                <span class="badge bg-secondary mb-2">

                    ${escapeHTML(
                        request.request_status
                    )}

                </span>


                <div>

                    ${actionButtons}

                </div>

            </div>


        </div>

    `;


    requestsContainer.appendChild(
        div
    );

}


// ==========================================
// UPDATE REQUEST
// ==========================================

async function updateRequest(
    requestId,
    action
) {

    try {

        const response =
            await fetch(
                `${API_URL}/provider/requests/${requestId}/${action}`,
                {
                    method: "PUT",

                    headers: {
                        Authorization:
                            `Bearer ${token}`
                    }
                }
            );


        const data =
            await response.json();


        if (!response.ok) {

            throw new Error(
                data.message ||
                "Request update failed"
            );

        }


        await loadRequests();

        await loadStats();


    } catch (error) {

        alert(
            error.message
        );

    }

}


// ==========================================
// LOGOUT
// ==========================================

document
    .getElementById("logoutButton")
    .addEventListener(
        "click",
        () => {

            localStorage.removeItem(
                "token"
            );

            localStorage.removeItem(
                "user"
            );

            window.location.href =
                "login.html";

        }
    );


// ==========================================
// ESCAPE HTML
// ==========================================

function escapeHTML(value) {

    if (
        value === null ||
        value === undefined
    ) {

        return "";

    }


    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");

}


// ==========================================
// INITIALIZE
// ==========================================

loadStats();

loadMyServices();

loadRequests();