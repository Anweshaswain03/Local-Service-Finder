const API_URL = "http://localhost:5000/api";


// ==========================================
// LOGIN
// ==========================================

const loginForm = document.getElementById("loginForm");

if (loginForm) {

    loginForm.addEventListener("submit", async function (event) {

        event.preventDefault();

        const email =
            document.getElementById("loginEmail").value.trim();

        const password =
            document.getElementById("loginPassword").value;

        const messageBox =
            document.getElementById("loginMessage");

        try {

            const response = await fetch(
                `${API_URL}/auth/login`,
                {
                    method: "POST",

                    headers: {
                        "Content-Type": "application/json"
                    },

                    body: JSON.stringify({
                        email,
                        password
                    })
                }
            );

            const data = await response.json();

            if (!response.ok) {

                messageBox.className =
                    "alert alert-danger";

                messageBox.textContent =
                    data.message || "Login failed";

                return;
            }


            // Save authentication information

            localStorage.setItem(
                "token",
                data.token
            );

            localStorage.setItem(
                "user",
                JSON.stringify(data.user)
            );


            messageBox.className =
                "alert alert-success";

            messageBox.textContent =
                "Login successful! Redirecting...";


            setTimeout(() => {

                if (data.user.role === "admin") {

                    window.location.href =
                        "admin-dashboard.html";

                } else if (data.user.role === "provider") {

                    window.location.href =
                        "provider-dashboard.html";

                } else {

                    window.location.href =
                        "services.html";

                }

            }, 800);


        } catch (error) {

            console.error(error);

            messageBox.className =
                "alert alert-danger";

            messageBox.textContent =
                "Unable to connect to the server. Make sure the backend is running.";

        }

    });

}


// ==========================================
// REGISTER
// ==========================================

const registerForm =
    document.getElementById("registerForm");

if (registerForm) {

    registerForm.addEventListener(
        "submit",
        async function (event) {

            event.preventDefault();

            const name =
                document.getElementById("registerName")
                    .value.trim();

            const email =
                document.getElementById("registerEmail")
                    .value.trim();

            const phone =
                document.getElementById("registerPhone")
                    .value.trim();

            const password =
                document.getElementById("registerPassword")
                    .value;

            const role =
                document.getElementById("registerRole")
                    .value;

            const messageBox =
                document.getElementById("registerMessage");


            try {

                const response = await fetch(
                    `${API_URL}/auth/register`,
                    {
                        method: "POST",

                        headers: {
                            "Content-Type": "application/json"
                        },

                        body: JSON.stringify({
                            name,
                            email,
                            password,
                            phone,
                            role
                        })
                    }
                );


                const data =
                    await response.json();


                if (!response.ok) {

                    messageBox.className =
                        "alert alert-danger";

                    messageBox.textContent =
                        data.message ||
                        "Registration failed";

                    return;
                }


                messageBox.className =
                    "alert alert-success";

                messageBox.textContent =
                    "Registration successful! Redirecting to login...";


                registerForm.reset();


                setTimeout(() => {

                    window.location.href =
                        "login.html";

                }, 1200);


            } catch (error) {

                console.error(error);

                messageBox.className =
                    "alert alert-danger";

                messageBox.textContent =
                    "Unable to connect to the server. Make sure the backend is running.";

            }

        }
    );

}